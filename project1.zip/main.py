from random import randint
from flask import Flask, render_template, request, redirect, url_for
from flask_mail import Mail, Message
from sklearn.preprocessing import LabelEncoder
from joblib import load
import pandas as pd
import pyrebase

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yb345677829'  # Add a secret key for session management

# Configure Flask-Mail
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USE_TLS'] = False  # Use SSL, not TLS
app.config['MAIL_USE_SSL'] = True
app.config['MAIL_USERNAME'] = 'hemanthd2429@gmail.com'  # Update with your email
app.config['MAIL_PASSWORD'] = 'zmoalxdykkkxzwas'  # Update with your email password
app.config['MAIL_DEFAULT_SENDER'] = 'noreply@example.com'


mail = Mail(app)

# Add your own Firebase configuration
config = {
 "apiKey": "AIzaSyBi3lUri8UKhtDgjzPfI9QUQxZPO_sva78",
  "authDomain": "major-9e2f4.firebaseapp.com",
  "databaseURL": "https://major-9e2f4-default-rtdb.firebaseio.com",
  "projectId": "major-9e2f4",
  "storageBucket": "major-9e2f4.appspot.com",
  "messagingSenderId": "512642884212",
  "appId": "1:512642884212:web:074a518577291379052721"
}


otp = randint(100000, 999999)  # Generate a 6-digit OTP

firebase = pyrebase.initialize_app(config)
auth = firebase.auth()
db = firebase.database()

person = {"is_logged_in": False, "name": "", "email": "", "uid": ""}

@app.route("/")
def login():
    return render_template("login.html")

@app.route("/signup")
def signup():
    return render_template("signup.html")
@app.route("/email")
def email():
    return render_template("email1.html")
@app.route("/success")
def success():
    return render_template("success.html")
@app.route("/login")
def login_page():
    return render_template("login.html")

@app.route("/welcome")
def welcome():
    if person["is_logged_in"]:
        return render_template("welcome.html", email=person["email"], name=person["name"])
    else:
        return redirect(url_for('login'))

@app.route("/result", methods=["POST", "GET"])
def result():
    if request.method == "POST":
        result = request.form
        email = result["email"]
        password = result["pass"]
        try:
            user = auth.sign_in_with_email_and_password(email, password)
            global person
            person["is_logged_in"] = True
            person["email"] = user["email"]
            person["uid"] = user["localId"]
            data = db.child("users").get()
            person["name"] = data.val()[person["uid"]]["name"]
            return redirect(url_for('welcome'))
        except:
            return redirect(url_for('login'))
    else:
        if person["is_logged_in"]:
            return redirect(url_for('welcome'))
        else:
            return redirect(url_for('login'))

@app.route("/register", methods=["POST", "GET"])
def register():
    if request.method == "POST":
        result = request.form
        email = result["email"]
        password = result["pass"]
        name = result["name"]
        try:
            auth.create_user_with_email_and_password(email, password)
            msg = Message(subject='Please enter the otp for completing the registration', sender='your_email@gmail.com', recipients=[email])
            msg.body = str(otp)
            mail.send(msg)
            return redirect(url_for('email'))
        except Exception as e:
            return f"An unexpected error occurred during registration: {e}"
    else:
        if person["is_logged_in"]:
            return redirect(url_for('welcome'))
        else:
            return render_template('register.html')  # Assuming you have a register.html template

@app.route('/validate', methods=["POST"])
def validate():
    user_otp = request.form['otp']
    if otp == int(user_otp):
        return redirect(url_for('success'))
    return "<h3> Please Try again</h3>"

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        uploaded_file = request.files['file']
        if uploaded_file.filename != '':
            test = pd.read_csv(uploaded_file)
            le = LabelEncoder()
            test['ID'] = pd.Series(le.fit_transform(test['ID']))
            X_test = test.values[:, 0:6]
            classifier = load('sso_model.joblib')
            y_pred = classifier.predict(X_test)
            predictions = []
            for i in range(len(test)):
                if y_pred[i] == 0:
                    predictions.append({"input": test.iloc[i].to_dict(), "prediction": 'No Anomaly Detected'})
                elif y_pred[i] == 1:
                    predictions.append({"input": test.iloc[i].to_dict(), "prediction": 'Anomaly Detected'})
            return render_template('result.html', predictions=predictions)
    return redirect(url_for('welcome'))

if __name__ == "__main__":
    app.run(debug=True)  # Run in debug mode for development
